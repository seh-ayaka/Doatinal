import axios from 'axios';
import React, { useState, useEffect } from "react";

//import ReactDOM from "react-dom/client";
import { BrowserRouter, Routes, Route } from "react-router-dom";

import { Outlet, Link } from "react-router-dom";

// const api = axios.create({
//     baseURL: 'http://localhost:3333/',
//     headers: { 
//         "Content-Type": "application/x-www-form-urlencoded"
//     }
// });


function App() {

 return (
   <BrowserRouter>
     <Routes>
       <Route path="/" element={<Layout />}>
         <Route index element={<Home />} />
         <Route path="listarusuarios" element={<ListarUsuarios />} />
         <Route path="listardoacoes" element={<ListarDoacoes />} />
         <Route path="cadastrar" element={<Cadastrar />} />
         <Route path="doacao" element={<CriarDoacao />} />
       </Route>
     </Routes>
   </BrowserRouter>
 );

}

const Layout = () => {
 return (
   <>
     <nav>
       <ul>
         <li>
           <Link to="/">Home</Link>
         </li>
         <li>
           <Link to="/listarusuarios">Listar</Link>
         </li>
         <li>
           <Link to="/listardoacoes">Listar</Link>
         </li>
         <li>
           <Link to="/cadastrar">Cadastrar</Link>
         </li>
         <li>
           <Link to="/doacao">Criar Doação</Link>
         </li>
       </ul>
     </nav>
     <hr></hr>

     <Outlet />
   </>
 )
};

const Home = () => {
 return(
   <>
   <h1>Home</h1>
   <p>IFSP</p>
   </>
 )
};

const Listarusuarios = () => {
  return (
    <>
    <h1>Listar Usuários</h1>
 <ListarUsuarios></ListarUsuarios>
    </>
    
 )
 };

 const Listardoacoes = () => {
  return (
    <>
    <h1>Listar Doações</h1>
 <ListarDoacoes></ListarDoacoes>
    </>
    
 )
 };

 const Cadastrar = () => {
  return (
    <>
    <h1>Cadastrar</h1>
 <CadastrarUsuario></CadastrarUsuario>
    </>
 )
 };

 const CriarDoacao = () => {
  return (
    <>
    <h1>Criar Doação</h1>
 <Doacao></Doacao>
    </>
 )
 };

// Lista_usuarios

function ListarUsuarios(){
 const [usuario, setData] = useState([]);
 useEffect(() => {
   const fetchData = async () => {
     const resposta = await axios.get('http://localhost:3333/usuario');
     setData(resposta.data);
   };
   fetchData();
 }, []);

 return (
   <table style={{ borderCollapse: 'collapse', width: '100%' }}>
       <thead>
         <tr style={{ borderBottom: '1px solid #ddd' }}>
           <th style={{ padding: '8px', textAlign: 'left' }}>Nome</th>
           <th style={{ padding: '8px', textAlign: 'left' }}>Email</th>
           <th style={{ padding: '8px', textAlign: 'left' }}>CPF</th>
           <th style={{ padding: '8px', textAlign: 'left' }}>Telefone</th>
           <th style={{ padding: '8px', textAlign: 'left' }}>Rg</th>
         </tr>
       </thead>
       <tbody>
         {usuario.map((usuario, index) => (
           <tr key={index} style={{ borderBottom: '1px solid #ddd' }}>
             <td style={{ padding: '8px' }}>{usuario.nome}</td>
             <td style={{ padding: '8px' }}>{usuario.email}</td>
             <td style={{ padding: '8px' }}>{usuario.cpf}</td>
             <td style={{ padding: '8px' }}>{usuario.telefone}</td>
             <td style={{ padding: '8px' }}>{usuario.rg}</td>
           </tr>
         ))}
       </tbody>
     </table>

 );

}

// Lista_doacoes

function ListarDoacoes(){
  const [doacao, setData] = useState([]);
  useEffect(() => {
    const fetchData = async () => {
      const resposta = await axios.get('http://localhost:3333/doacao');
      setData(resposta.data);
    };
    fetchData();
  }, []);
 
  return (
    <table style={{ borderCollapse: 'collapse', width: '100%' }}>
        <thead>
          <tr style={{ borderBottom: '1px solid #ddd' }}>
            <th style={{ padding: '8px', textAlign: 'left' }}>Valor</th>
            <th style={{ padding: '8px', textAlign: 'left' }}>Data</th>
            <th style={{ padding: '8px', textAlign: 'left' }}>Tipo</th>
            <th style={{ padding: '8px', textAlign: 'left' }}>Descrição</th>
            <th style={{ padding: '8px', textAlign: 'left' }}>Título</th>
            <th style={{ padding: '8px', textAlign: 'left' }}>Status</th>
          </tr>
        </thead>
        <tbody>
          {doacao.map((doacao, index) => (
            <tr key={index} style={{ borderBottom: '1px solid #ddd' }}>
              <td style={{ padding: '8px' }}>{doacao.valor}</td>
              <td style={{ padding: '8px' }}>{doacao.data}</td>
              <td style={{ padding: '8px' }}>{doacao.tipo}</td>
              <td style={{ padding: '8px' }}>{doacao.descricao}</td>
              <td style={{ padding: '8px' }}>{doacao.titulo}</td>
              <td style={{ padding: '8px' }}>{doacao.status}</td>
            </tr>
          ))}
        </tbody>
      </table>
 
  );
 
 }



const CadastrarUsuario = () => {
 const [nome, setNome] = useState('');
 const [email, setEmail] = useState('');
 const [cpf, setCpf] = useState('');
 const [telefone, setTelefone] = useState('');
 const [senha, setSenha] = useState('');
 const [rg, setRg] = useState('');
 

 const handleSubmit = async (e) => {
   e.preventDefault();

   try {
     // Envia os dados para a rota usando o método POST
     await axios.post('http://localhost:3333/usuario', { nome, email, cpf, telefone, senha, rg });
     alert('Dados enviados com sucesso!');
     // Limpa os campos após o envio bem-sucedido
     setNome('');
     setEmail('');
     setCpf('');
     setTelefone('');
     setSenha('');
     setRg('');

   } catch (error) {
     console.error('Erro ao enviar dados:', error);
     alert('Erro ao enviar dados. Consulte o console para mais detalhes.');
   }
 };

 return (
   <div>
     <h2>Formulário de Usuário</h2>
     <form onSubmit={handleSubmit}>
       <label>
         Nome:
         <input
           type="text"
           value={nome}
           onChange={(e) => setNome(e.target.value)}
           required
         />
       </label>
       <br />
       <label>
         Email:
         <input
           type="email"
           value={email}
           onChange={(e) => setEmail(e.target.value)}
           required
         />
       </label>
       <br />
       <label>
         CPF:
         <input
           type="number"
           value={cpf}
           onChange={(e) => setCpf(e.target.value)}
           required
         />
       </label>
       <br />
       <label>
         Telefone:
         <input
           type="tel"
           value={telefone}
           onChange={(e) => setTelefone(e.target.value)}
           required
         />
       </label>
       <br />
       <label>
         Senha:
         <input
           type="password"
           value={senha}
           onChange={(e) => setSenha(e.target.value)}
           required
         />
       </label>
       <br />
       <label>
         Rg:
         <input
           type="number"
           value={rg}
           onChange={(e) => setRg(e.target.value)}
           required
         />
       </label>
       <br />
       <br />
       <button type="submit">Enviar</button>
     </form>
   </div>
 );
};

// Doacao

const Doacao = () => {
  const [valor, setValor] = useState('');
  const [data, setData] = useState('');
  const [tipo, setTipo] = useState('');
  const [descricao, setDescricao] = useState('');
  const [titulo, setTitulo] = useState('');
  const [status, setStatus] = useState('');
  
 
  const handleSubmit = async (e) => {
    e.preventDefault();
 
    try {
      // Envia os dados para a rota usando o método POST
      await axios.post('http://localhost:3333/doacao', { valor, data, tipo, descricao, titulo, status});
      alert('Dados enviados com sucesso!');
      // Limpa os campos após o envio bem-sucedido
      setValor('');
      setData('');
      setTipo('');
      setDescricao('');
      setTitulo('');
      setStatus('');
 
    } catch (error) {
      console.error('Erro ao enviar dados:', error);
      alert('Erro ao enviar dados. Consulte o console para mais detalhes.');
    }
  };
 
  return (
    <div>
      <h2>Formulário de Doações</h2>
      <form onSubmit={handleSubmit}>
        <label>
          Valor a ser arrecadado:
          <input
            type="number"
            value={valor}
            onChange={(e) => setValor(e.target.value)}
            required
          />
        </label>
        <br />
        <label>
          Data:
          <input
            type="date"
            value={data}
            onChange={(e) => setData(e.target.value)}
            required
          />
        </label>
        <br />
        <label>
          Tipo de Pagamento:
          <input
            type="text"
            value={tipo}
            onChange={(e) => setTipo(e.target.value)}
            required
          />
        </label>
        <br />
        <label>
          Descrição:
          <input
            type="text"
            value={descricao}
            onChange={(e) => setDescricao(e.target.value)}
            required
          />
        </label>
        <br />
        <label>
          Título:
          <input
            type="text"
            value={titulo}
            onChange={(e) => setTitulo(e.target.value)}
            required
          />
        </label>
        <br />
        <label>
          Status da doação:
          <input
            type="text"
            value={status}
            onChange={(e) => setStatus(e.target.value)}
            required
          />
        </label>
        <br />
        <br />
        <button type="submit">Enviar</button>
      </form>
    </div>
  );
 };

export default App;
