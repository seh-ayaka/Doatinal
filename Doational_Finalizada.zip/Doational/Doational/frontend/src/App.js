
import axios from 'axios';
import React, { useState, useEffect } from "react";

//import ReactDOM from "react-dom/client";
import { BrowserRouter, Routes, Route } from "react-router-dom";

import { Outlet, Link } from "react-router-dom";

import CampanhaImg from './img/Campanha.png';
import LogoImg from './img/logo.png';
import face from './img/facebook.png';
import insta from './img/instagram.png';
import github from './img/github.png';
import twitter from './img/twitter.png';

// Rotas ou links
function App() {
  return (
    <BrowserRouter>
      <Routes>
        <Route path="/" element={<Layout />}>
          <Route index element={<Home />} />
          <Route path="listardoacao" element={<Listar_Doacao />} />
          <Route path="listarusuarios" element={<Listar_Usuarios />} />
          <Route path="cadastrar" element={<Cadastrar />} />
          <Route path="doacao" element={<Doar />} />
          <Route path="campanha" element={<Campanha />} />
        </Route>
      </Routes>
    </BrowserRouter>
  );
}


// Cabeçalho presente em todas as páginas
const Layout = () => {
  return (
    <>
      <header class="w100">
        <div class="container justify">
          <a href="/">
            <div class="logo justify">
              <img src={LogoImg} alt="Logo"></img>
              <h2>Doational</h2>
            </div>
          </a>
          <input type="search" placeholder="Pesquise aqui"></input>
          <div class="botoes justify">
            <a href="/listarusuarios">Usuários</a>
            <a href="/cadastrar" class="btn1">Cadastrar</a>
          </div>
        </div>
      </header>

      <Outlet />
    </>
  )
};


// Html da página principal/início
const Home = () => {
  return (
    <>
      <section id="tutorial">
        <div class="container h100">
          <div class="justify h100">
            <div class="w50 center" id="vertical">
              <h2>Não sabe como fazer doações no site?</h2>
              <p>Logo abaixo estão todas as doações publicadas, basta
                clicar em uma delas, precionar o botão Quero doar, 
                preencher seus dados, enviar e pronto 😉
              </p>
            </div>
            <div class="w50 center" id="video">
              <iframe src="https://www.youtube.com/embed/AQ1PgO0Q_2I" title="Apresentação IFSP Campus Caraguatatuba"
                frameborder="0"
                allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
                allowfullscreen></iframe>
            </div>
          </div>
        </div>
      </section>

      <section id="doations">
        <h1>Últimas Doations</h1>
      </section>

      <div class="container">
        <section id="grade">

          <div class="col">
            <a href="/campanha">
              <div class="campanha-card">
                <img class="rounded img-fluid d-block w-100 fit-cover" src={CampanhaImg} alt="Imagem da Campanha"></img>
                <h4>Compra de prédio institucional</h4>
                <progress value="50" max="100"> 50% </progress>
                <p>Meta: R$ 2,00</p>
              </div>
            </a>
          </div>

          <div class="col">
            <div class="campanha-card">
              <img class="rounded img-fluid d-block w-100 fit-cover" src="https://cdn.bootstrapstudio.io/placeholders/1400x800.png" alt="Imagem da Campanha"></img>
              <h4>Exemplo de campanha</h4>
              <progress value="0" max="100"> 0% </progress>
              <p>Meta: Valor</p>
            </div>
          </div>

          <div class="col">
            <div class="campanha-card">
              <img class="rounded img-fluid d-block w-100 fit-cover" src="https://cdn.bootstrapstudio.io/placeholders/1400x800.png" alt="Imagem da Campanha"></img>
              <h4>Exemplo de campanha</h4>
              <progress value="0" max="100"> 0% </progress>
              <p>Meta: Valor</p>
            </div>
          </div>

          <div class="col">
            <div class="campanha-card">
              <img class="rounded img-fluid d-block w-100 fit-cover" src="https://cdn.bootstrapstudio.io/placeholders/1400x800.png" alt="Imagem da Campanha"></img>
              <h4>Exemplo de campanha</h4>
              <progress value="0" max="100"> 0% </progress>
              <p>Meta: Valor</p>
            </div>
          </div>

          <div class="col">
            <div class="campanha-card">
              <img class="rounded img-fluid d-block w-100 fit-cover" src="https://cdn.bootstrapstudio.io/placeholders/1400x800.png" alt="Imagem da Campanha"></img>
              <h4>Exemplo de campanha</h4>
              <progress value="0" max="100"> 0% </progress>
              <p>Meta: Valor</p>
            </div>
          </div>

          <div class="col">
            <div class="campanha-card">
              <img class="rounded img-fluid d-block w-100 fit-cover" src="https://cdn.bootstrapstudio.io/placeholders/1400x800.png" alt="Imagem da Campanha"></img>
              <h4>Exemplo de campanha</h4>
              <progress value="0" max="100"> 0% </progress>
              <p>Meta: Valor</p>
            </div>
          </div>

        </section>
        <br></br>
        <br></br>

      </div>

      <footer>
        <div class="container">
          <div>
            <div class="justify">
              <div class="w50 justify">
                <div class="w50">
                  <a href="">Quem Somos</a>
                  <a href="">Login</a>
                  <a href="">Criar Doation</a>
                </div>
                <div class="w50">
                  <a href="">Política de Privacidade</a>
                  <a href="">Fale conosco</a>
                </div>
              </div>
              <div class="w30">
                <div class="redes center w100" id="vertical">
                  <p>Redes Sociais</p>
                  <div class="justify">
                    <a href=""><img src={twitter} alt=""></img></a>
                    <a href=""><img src={github} alt=""></img></a>
                    <a href=""><img src={insta} alt=""></img></a>
                    <a href=""><img src={face} alt=""></img></a>
                  </div>
                </div>
              </div>
            </div>
            <hr color="white">
            </hr>
            <div class="justify">
              <div class="logo justify">
                <img src={LogoImg} alt="Logo"></img>
                <h2>Doational</h2>
              </div>
              <p>© Todos os direitos reservados</p>
            </div>
          </div>
        </div>
      </footer>
    </>
  )
};

// Html da página de cadastro de usuário
const Cadastrar = () => {
  return (
    <>
      <br></br>
      <br></br>
      <br></br>
      <br></br>
      <br></br>
      <br></br>
      <br></br>
      <div class="container">
        <div class="card ">
          <div class="card-doacao">
            <CadastrarUsuario></CadastrarUsuario>
          </div>
        </div>
      </div>
    </>
  )
};

// Html da página da campanha
const Campanha = () => {
  return (
    <>
      <br></br>
      <br></br>
      <br></br>
      <br></br>
      <br></br>
      <br></br>
      <br></br>

      <section>
        <div class="container">
          <div class="info">
            <h1>Prédio escolar</h1>
            <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Saepe ipsa consequatur quod, reiciendis pariatur magnam rem maiores, dicta, unde aliquid officiis minima ratione dolorum ipsam sed non nostrum velit mollitia praesentium. Nesciunt, omnis aliquam praesentium totam optio saepe beatae nulla veritatis, fuga excepturi ratione, porro sequi quidem doloremque? Numquam, quo!</p>
          </div>

          <br></br>

          <div>
            <div class="col horizontal gap">
              <img class="w50" src={CampanhaImg} alt="Imagem da Campanha"></img>

              <div class="w50 campanha-card">
                <h4>Compra de prédio institucional</h4>
                <progress value="50" max="100"> 50% </progress>
                <p>Meta: R$ 2,00</p>
                <div class="horizontal gap">
                  <a href="/doacao" class="btn1">Quero doar</a>
                  <a href="/listardoacao" class="btn2">Listar doações já feitas</a>
                </div>
              </div>

            </div>
          </div>
        </div>
      </section>

      <br></br>
      <br></br>
      <br></br>

      <footer>
        <div class="container">
          <div>
            <div class="justify">
              <div class="w50 justify">
                <div class="w50">
                  <a href="">Quem Somos</a>
                  <a href="">Login</a>
                  <a href="">Criar Doation</a>
                </div>
                <div class="w50">
                  <a href="">Política de Privacidade</a>
                  <a href="">Fale conosco</a>
                </div>
              </div>
              <div class="w30">
                <div class="redes center w100" id="vertical">
                  <p>Redes Sociais</p>
                  <div class="justify">
                    <a href=""><img src={twitter} alt=""></img></a>
                    <a href=""><img src={github} alt=""></img></a>
                    <a href=""><img src={insta} alt=""></img></a>
                    <a href=""><img src={face} alt=""></img></a>
                  </div>
                </div>
              </div>
            </div>
            <hr color="white">
            </hr>
            <div class="justify">
              <div class="logo justify">
                <img src={LogoImg} alt="Logo"></img>
                <h2>Doational</h2>
              </div>
              <p>© Todos os direitos reservados</p>
            </div>
          </div>
        </div>
      </footer>
    </>
  )
};

// Html da página de doação para a campanha 
const Doar = () => {
  return (
    <>
      <br></br>
      <br></br>
      <br></br>
      <br></br>
      <br></br>
      <br></br>
      <br></br>
      <div class="container">
        <div class="card ">
          <div class="card-doacao">
            <FazerDoacao></FazerDoacao>
          </div>
        </div>
      </div>
    </>
  )
};

// Html da página listar doações
const Listar_Doacao = () => {
  return (
    <>
      <br></br>
      <br></br>
      <br></br>
      <br></br>
      <br></br>
      <br></br>
      <br></br>
      <div class="container">
        <h1>Listar Doações</h1>
        <ListarDoacao></ListarDoacao>
      </div>
    </>
  )
};

// Html da página listar usuários
const Listar_Usuarios = () => {
  return (
    <>
      <br></br>
      <br></br>
      <br></br>
      <br></br>
      <br></br>
      <br></br>
      <br></br>
      <div class="container">
        <h1>Listar Usuários</h1>
        <ListarUsuarios></ListarUsuarios>
      </div>
    </>
  )
};

//Função De listagem dos usuários 
function ListarUsuarios() {
  const [usuario, setData] = useState([]);
  useEffect(() => {
    const fetchData = async () => {
      const resposta = await axios.get('http://localhost:3333/usuario');
      setData(resposta.data);
    };
    fetchData();
  }, []);

  return (
    <table style={{ borderCollapse: 'collapse', width: '100%' }}>
      <thead>
        <tr style={{ borderBottom: '1px solid #ddd' }}>
          <th style={{ padding: '8px', textAlign: 'left' }}>Nome</th>
          <th style={{ padding: '8px', textAlign: 'left' }}>Email</th>
          <th style={{ padding: '8px', textAlign: 'left' }}>CPF</th>
          <th style={{ padding: '8px', textAlign: 'left' }}>Telefone</th>
          <th style={{ padding: '8px', textAlign: 'left' }}>Cep</th>
          <th style={{ padding: '8px', textAlign: 'left' }}>Cidade</th>
          <th style={{ padding: '8px', textAlign: 'left' }}>Estado</th>
        </tr>
      </thead>
      <tbody>
        {usuario.map((usuario, index) => (
          <tr key={index} style={{ borderBottom: '1px solid #ddd' }}>
            <td style={{ padding: '8px' }}>{usuario.nome}</td>
            <td style={{ padding: '8px' }}>{usuario.email}</td>
            <td style={{ padding: '8px' }}>{usuario.cpf}</td>
            <td style={{ padding: '8px' }}>{usuario.telefone}</td>
            <td style={{ padding: '8px' }}>{usuario.cep}</td>
            <td style={{ padding: '8px' }}>{usuario.cidade}</td>
            <td style={{ padding: '8px' }}>{usuario.estado}</td>
          </tr>
        ))}
      </tbody>
    </table>
  );
}

//Função de Cadastrar usuários
const CadastrarUsuario = () => {
  const [nome, setNome] = useState('');
  const [email, setEmail] = useState('');
  const [cpf, setCpf] = useState('');
  const [telefone, setTelefone] = useState('');
  const [senha, setSenha] = useState('');
  const [cep, setCep] = useState('');
  const [cidade, setCidade] = useState('');
  const [estado, setEstado] = useState('');


  const handleSubmit = async (e) => {
    e.preventDefault();

    try {
      // Envia os dados para a rota usando o método POST
      await axios.post('http://localhost:3333/usuario', { nome, email, cpf, telefone, senha, cep, cidade, estado });
      alert('Dados enviados com sucesso!');
      // Limpa os campos após o envio bem-sucedido
      setNome('');
      setEmail('');
      setCpf('');
      setTelefone('');
      setSenha('');
      setCep('');
      setCidade('');
      setEstado('');

    } catch (error) {
      console.error('Erro ao enviar dados:', error);
      alert('Erro ao enviar dados. Consulte o console para mais detalhes.');
    }
  };

  return (
    <div>
      <h2>Formulário de Usuário</h2>
      <form onSubmit={handleSubmit}>
        <label>
          Nome:
          <input
            type="text"
            value={nome}
            onChange={(e) => setNome(e.target.value)}
            required
          />
        </label>
        <br />
        <label>
          Email:
          <input
            type="email"
            value={email}
            onChange={(e) => setEmail(e.target.value)}
            required
          />
        </label>
        <br />
        <label>
          CPF:
          <input
            type="number"
            value={cpf}
            onChange={(e) => setCpf(e.target.value)}
            required
          />
        </label>
        <br />
        <label>
          Telefone:
          <input
            type="tel"
            value={telefone}
            onChange={(e) => setTelefone(e.target.value)}
            required
          />
        </label>
        <br />
        <label>
          Cep:
          <input
            type="number"
            value={cep}
            onChange={(e) => setCep(e.target.value)}
            required
          />
        </label>
        <br />
        <label>
          Cidade:
          <input
            type="text"
            value={cidade}
            onChange={(e) => setCidade(e.target.value)}
            required
          />
        </label>
        <br />
        <label>
          Estado:
          <input
            type="text"
            value={estado}
            onChange={(e) => setEstado(e.target.value)}
            required
          />
        </label>
        <br />
        <label>
          Senha:
          <input
            type="password"
            value={senha}
            onChange={(e) => setSenha(e.target.value)}
            required
          />
        </label>
        <br />
        <br />
        <button class="btn1" type="submit">Enviar</button>
      </form>
    </div>
  );
};

//Função de cadastrar doação
const FazerDoacao = () => {
  const [nome, setNome] = useState('');
  const [cpf, setCpf] = useState('');
  const [valor, setValor] = useState('');
  const [modelo, setModelo] = useState('');
  const [mensagem, setMensagem] = useState('');


  const handleSubmit = async (e) => {
    e.preventDefault();

    try {
      // Envia os dados para a rota usando o método POST
      await axios.post('http://localhost:3333/doacao', { nome, cpf, valor, modelo, mensagem });
      alert('Dados enviados com sucesso!');
      // Limpa os campos após o envio bem-sucedido
      setNome('');
      setCpf('');
      setValor('');
      setModelo('');
      setMensagem('');

    } catch (error) {
      console.error('Erro ao enviar dados:', error);
      alert('Erro ao enviar dados. Consulte o console para mais detalhes.');
    }
  };


  return (
    <div>
      <h2>Formulário de doação</h2>
      <br></br>
      <form onSubmit={handleSubmit}>
        <label>
          Nome:
          <input
            type="text"
            value={nome}
            onChange={(e) => setNome(e.target.value)}
            required
          />
        </label>
        <br />
        <label>
          CPF:
          <input
            type="number"
            value={cpf}
            onChange={(e) => setCpf(e.target.value)}
            required
          />
        </label>
        <br />
        <label>
          Valor:
          <input
            type="number"
            value={valor}
            onChange={(e) => setValor(e.target.value)}
            required
          />
        </label>
        <br />
        <label>
          Forma de Pagamento:
          <input
            type="text"
            value={modelo}
            onChange={(e) => setModelo(e.target.value)}
            required
          />
        </label>
        <br />
        <label>
          Mensagem:
          <input
            type="text"
            value={mensagem}
            onChange={(e) => setMensagem(e.target.value)}
            required
          />
        </label>
        <br />
        <br />
        <button class="btn1" type="submit">Enviar</button>
      </form>
    </div>
  );
};

//Função de listar doações
function ListarDoacao() {
  const [doacao, setData] = useState([]);
  useEffect(() => {
    const fetchData = async () => {
      const resposta = await axios.get('http://localhost:3333/doacao');
      setData(resposta.data);
    };
    fetchData();
  }, []);

  return (
    <table style={{ borderCollapse: 'collapse', width: '100%' }}>
      <thead>
        <tr style={{ borderBottom: '1px solid #ddd' }}>
          <th style={{ padding: '8px', textAlign: 'left' }}>Nome</th>
          <th style={{ padding: '8px', textAlign: 'left' }}>CPF</th>
          <th style={{ padding: '8px', textAlign: 'left' }}>Valor</th>
          <th style={{ padding: '8px', textAlign: 'left' }}>Forma de Pagamento</th>
          <th style={{ padding: '8px', textAlign: 'left' }}>Mensagem</th>
        </tr>
      </thead>
      <tbody>
        {doacao.map((doacao, index) => (
          <tr key={index} style={{ borderBottom: '1px solid #ddd' }}>
            <td style={{ padding: '8px' }}>{doacao.nome}</td>
            <td style={{ padding: '8px' }}>{doacao.cpf}</td>
            <td style={{ padding: '8px' }}>{doacao.valor}</td>
            <td style={{ padding: '8px' }}>{doacao.modelo}</td>
            <td style={{ padding: '8px' }}>{doacao.mensagem}</td>
          </tr>
        ))}
      </tbody>
    </table>
  );
}

// Final 

export default App;
